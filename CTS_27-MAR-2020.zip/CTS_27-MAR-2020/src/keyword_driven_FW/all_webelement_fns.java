package keyword_driven_FW;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class all_webelement_fns {
	WebDriver dr;
	public all_webelement_fns(WebDriver dr) {
		// TODO Auto-generated constructor stub
		this.dr=dr;
	}
  public void enter_txt(String xp,String data)
  {
	  dr.findElement(By.xpath(xp)).sendKeys(data);
  }
  public void click(String xp)
  {
	  dr.findElement(By.xpath(xp)).click();
  }
  public void launchChrome(String url) {
	  System.setProperty("webdriver.chrome.driver","C://Users//Hemanth//Downloads//chromedriver_win32//chromedriver.exe");
		dr =new ChromeDriver();
		dr.get(url);	
  }
}
