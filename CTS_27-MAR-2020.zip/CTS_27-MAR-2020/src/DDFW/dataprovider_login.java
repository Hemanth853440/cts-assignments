package DDFW;

public class dataprovider_login<Startingweb> {
	Startingweb test;



{

}
}