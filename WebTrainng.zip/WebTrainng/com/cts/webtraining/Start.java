package com.cts.webtraining;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;

public class Start {
  @Test
  public void f() {
	  dr.findElement(By.className("ico-login")).click();
		dr.findElement(By.id("Email")).sendKeys("hemanthpardhani@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("9000740616");
	    dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	    String Actual = dr.getTitle();
      String Expected = "demowebshop";

      if (Actual.equals(Expected)) {
                 System.out.println("Test Passed!");
      } else {
                 System.out.println("Test Failed");
      }

      dr.close();

  }
  @BeforeMethod
  public void beforeMethod() {
	  System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		WebDriver dr =new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com/");
  }

}
