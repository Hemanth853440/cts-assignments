package tests;

import org.testng.annotations.Test;

import pages.HOME_PAGE;
import pages.LOGIN_PAGE;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;

public class TestPOM {
	WebDriver dr;
	HOME_PAGE hp;
	LOGIN_PAGE lp;
  @Test
  public void pom() {
	  hp.click_login_link();
	  lp.do_login("hemanthpardhani@gmail.com","9000740616");
	  }
  
  @BeforeClass
  public void beforeClass() {
	  System.setProperty("webdriver.chrome.driver","C://Users//Hemanth//Downloads//chromedriver_win32//chromedriver.exe");
	  dr=new ChromeDriver();
	  dr.get("http://demowebshop.tricentis.com/");
	  hp=new HOME_PAGE(dr);
	  lp=new LOGIN_PAGE(dr);
	}
  

}
