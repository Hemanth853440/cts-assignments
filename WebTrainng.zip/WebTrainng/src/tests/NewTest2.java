package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.Wbotrainingg;

public class NewTest2 {
	Wbotrainingg demoweb;
  @Test
  public void test() {
	  String actual;
	  String exp="hemanthpardhani@gmail.com";
	  demoweb =new Wbotrainingg();
	  actual=demoweb.login();
	  Assert.assertEquals(actual, exp);}

  }

