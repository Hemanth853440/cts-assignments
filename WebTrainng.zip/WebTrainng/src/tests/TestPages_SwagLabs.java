package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages1.Login_Page_SwagLabs;
import pages1.Products_Page_SwagLabs;

public class TestPages_SwagLabs {
	
  WebDriver driver;
  pages1.Login_Page_SwagLabs lp;
  pages1.Products_Page_SwagLabs pp;
  @BeforeClass
  public void LaunchBrowser() {
	  
	  System.setProperty("webdriver.chrome.driver","C://Users//Hemanth//Downloads//chromedriver_win32//chromedriver.exe");
	  driver = new  ChromeDriver();
	  driver.manage().window().maximize();
	  driver.get("https://www.saucedemo.com/");
	   
	  lp = new Login_Page_SwagLabs(driver);
	  pp = new Products_Page_SwagLabs(driver);
  }

  @Test
  public void Test() 
  {
	  lp.Verify_title();
	  lp.Login("standard_user", "secret_sauce");
	   pp.Verify_Products();
  }
  
  @AfterClass
  public void afterClass() throws InterruptedException 
  {
	  Thread.sleep(2000);
	  driver.quit();
  }
}



