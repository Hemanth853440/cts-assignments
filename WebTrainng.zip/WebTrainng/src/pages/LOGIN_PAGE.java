package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LOGIN_PAGE {
	WebDriver dr2;
	
	public LOGIN_PAGE(WebDriver dr) 
	    {this.dr2=dr;}
 public void entr_email(String emailid) {
	dr2.findElement(By.id("Email")).sendKeys("hemanthpardhani@gmail.com");
	}
public void enter_password(String password) {
	dr2.findElement(By.id("Password")).sendKeys("9000740616");
}
public void click_login_btn() {
    dr2.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	}

public void do_login(String emailid, String password) {
	// TODO Auto-generated method stub
	   this.entr_email(emailid);
	   this.enter_password(password);
	   this.click_login_btn();
	   
}


}
