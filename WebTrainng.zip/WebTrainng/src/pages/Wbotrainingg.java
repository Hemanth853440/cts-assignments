package pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Wbotrainingg {
	public WebDriver dr;
  @Test
  public String login () {

		dr.findElement(By.className("ico-login")).click();
		dr.findElement(By.id("Email")).sendKeys("hemanthpardhani@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("9000740616");
	    dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
	    String Actual = dr.getTitle();
        String Expected = dr.getTitle();
      if (Actual.equals(Expected)) 
      {
                 System.out.println("Test Passed!");
      } else {
                 System.out.println("Test Failed");
      }
	return Expected;

  }
  @BeforeMethod
  public void beforeMethod() {
	  
		System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		 dr =new ChromeDriver();
		    dr.get("http://demowebshop.tricentis.com/");
		dr.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		
  }

  @AfterMethod
  public void afterMethod() {
	  dr.quit();
  }

}
