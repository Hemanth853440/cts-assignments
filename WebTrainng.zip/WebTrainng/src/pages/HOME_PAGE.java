package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HOME_PAGE {
	WebDriver dr1;

	public HOME_PAGE(WebDriver dr) {
		// TODO Auto-generated constructor stub
		this.dr1=dr;
	}

	public void click_login_link()
	{
		dr1.findElement(By.className("ico-login")).click();
	}
}
