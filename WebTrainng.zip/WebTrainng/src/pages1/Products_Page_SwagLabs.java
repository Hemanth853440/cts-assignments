package pages1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class Products_Page_SwagLabs {
	
	WebDriver driver2;
	By txt= new By.ByClassName("product_label");
	
	public Products_Page_SwagLabs(WebDriver driver)
	{
		this.driver2=driver;
	}
	
	public void Verify_Products()
	{
		String exp_text="Products";
		String act_text=driver2.findElement(txt).getText();
		Assert.assertEquals(exp_text, act_text, "Text Mismatch");
	}

}
