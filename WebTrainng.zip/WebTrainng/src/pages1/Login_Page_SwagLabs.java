package pages1;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class Login_Page_SwagLabs {
	
	WebDriver driver1;
	
	By UN= new By.ById("user-name");
	By pwd= new  By.ById("password");
	By Login_btn= new By.ByXPath("//*[@value='LOGIN']");
	
	public Login_Page_SwagLabs(WebDriver driver)
	{	
		this.driver1=driver;
	}
	
	public void Verify_title()
	{	String exp_title="Swag Labs";
		String act_title=driver1.getTitle();
		Assert.assertEquals(act_title, exp_title,"Title Mismatch");			
		}
	
	public void Username(String un)	
	{
		driver1.findElement(UN).sendKeys("standard_user");
	}
	
	public void Password(String Password)
	{	
		driver1.findElement(pwd).sendKeys("secret_sauce");
	}
	
	public void Login_click()
	{	
		driver1.findElement(Login_btn).click();
	}
	
	public void Login(String un, String Password)
	{	
		this.Username(un);
		this.Password(Password);
		this.Login_click();
	}
	

}

